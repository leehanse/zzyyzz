
</td></tr></table>

</div> <!-- end main1 -->

<div id="footer_nav">
  <table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td nowrap="nowrap"><a href="/About" class="mainlevel" >About</a><a href="/Advertise" class="mainlevel" >Advertise</a><a href="/Contact" class="mainlevel" >Contact</a><a href="/Events-Calendar" class="mainlevel" >Events</a><a href="/Press" class="mainlevel" >Press</a><a href="/Privacy" class="mainlevel" >Privacy</a><a href="https://www.imbibemagazine.com/subscribe.php?SourceCode=footer" class="mainlevel" >Subscribe</a><a href="/component/option,com_xmap/Itemid,27/sitemap,1/" class="mainlevel" >Site Map</a><a href="/FAQs" class="mainlevel" >FAQs</a></td></tr></table>

</div> <!-- end footer_nav -->
    
<div id="credits">
  <p>&copy; 2005 - 2013, Imbibe. All Rights Reserved.</p>
</div>

</div> <!-- end main -->
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-842203-1");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>
