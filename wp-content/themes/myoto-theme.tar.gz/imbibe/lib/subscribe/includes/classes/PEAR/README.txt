This directory is assembled from parts of the PEAR repository at
http://pear.php.net/. Rather than having a complete PEAR installation on each
website or assuming the webserver has an accessible PEAR installation, this is
the minimum needed to send emails.

Directory contents and source:

PEAR
|
+--/Mail                    Mail-1.1.14.tgz
|  |
|  +--mail.php                   "
|  |
|  +--null.php                   "
|  |
|  +--RFC822.php                 "
|  |
|  +--sendmail.php               "
|  |
|  +--smtp.php                   "
|  
+--/NET
|  |
|  +--SMTP.php              Net_SMTP-1.2.8
|  |
|  +--Socket.php            Net_Socket-1.0.6
|
+--Mail.php                 Mail-1.1.14.tgz
|
+--PEAR.php                 PEAR-1.5.0.tgz
|
+--README.txt               this file
