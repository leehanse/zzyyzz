<div id="header">

<!-- <img src="images/stories/header_renewal.gif" alt="Renew and Save" />  -->
<img src="<?php echo home_url();?>/images/spacer.gif" width="1" height="1" onload="javascript:pageTracker._trackPageview('/funnel_renew/step0.html');" />
</div>



