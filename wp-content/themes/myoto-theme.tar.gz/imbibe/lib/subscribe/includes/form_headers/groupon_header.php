<div id="header">

<img src="<?php echo home_url();?>/images/stories/commerce_images/form_headers/groupon_header.png" alt="Welcome Groupon Shoppers!" />


</div>



