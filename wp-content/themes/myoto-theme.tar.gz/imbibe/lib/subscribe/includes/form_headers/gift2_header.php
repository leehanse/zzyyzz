<div id="header">

<img src="<?php echo home_url();?>/images/stories/commerce_images/form_headers/gift2_header.jpg" alt="Give More and Save!" onload="javascript:pageTracker._trackPageview('/funnel_gift/step1.html');" />
<p><strong>&nbsp;&nbsp;&nbsp;To give a 1-year gift subscription, click <a href="https://www.imbibemagazine.com/gift.php?SourceCode=gift6"><strong>here.</strong></a></strong></p>
<p><br /></p>
<p class="small_text">&nbsp;&nbsp;&nbsp;Add $20/year for all subscriptions mailed outside the United States.</p>

</div>



