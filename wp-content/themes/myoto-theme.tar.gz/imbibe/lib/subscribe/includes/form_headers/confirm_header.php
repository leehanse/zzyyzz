<div id="header">

<img src="<?php echo home_url();?>/images/stories/spacer.gif" width="707" height="1" alt="Thank you for your order!" />
<p class="small_text"></p>

</div>



