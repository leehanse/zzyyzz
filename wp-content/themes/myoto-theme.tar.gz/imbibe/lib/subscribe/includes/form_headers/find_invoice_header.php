<div id="header">

<!-- <img src="images/stories/header_invoice.gif" alt="Pay Invoice" />  -->
<img src="<?php echo home_url();?>/images/spacer.gif" width="1" height="1" onload="javascript:pageTracker._trackPageview('/funnel_payup/step0.html');" />
</div>



