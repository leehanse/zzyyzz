<div id="header">

<img src="<?php echo home_url();?>/images/stories/commerce_images/form_headers/cedl_header.png" alt="Subscribe and Save Today!" />
<p class="small_text">&nbsp;&nbsp;&nbsp;Add $20/year for all subscriptions mailed outside the United States.</p>

</div>



