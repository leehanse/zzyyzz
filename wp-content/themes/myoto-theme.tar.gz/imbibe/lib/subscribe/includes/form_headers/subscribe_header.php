<div id="header">

<img src="<?php echo home_url();?>/images/stories/commerce_images/form_headers/subscribe_header.gif" alt="Subscribe Today!" onload="javascript:pageTracker._trackPageview('/funnel_subscribe/step1.html');" />
<p class="small_text">&nbsp;&nbsp;&nbsp;&nbsp;Add $20/year for all subscriptions mailed outside the United States.</p>

</div>



