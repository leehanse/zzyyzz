
<div id="upcoming">
<h1>Upcoming Events</h1>
<p class="sm">Oct 7</p>
<p class="sm">New York City</p>
<p class="sm red">RumFest NYC</p>
<p class="sm">&nbsp;</p>
<p class="sm">October 9-11</p>
<p class="sm">Denver, Colo.</p>
<p class="sm red">Great American Beer Festival</p>
<p class="sm">&nbsp;</p>
<p class="sm">October 14</p>
<p class="sm">Washington, DC</p>
<p class="sm red">Great Hotel Bars</p>
<p class="micro_link"><a href="/events.php">See all events<span class="red_arrows"> >> </span></a></p>
</div>

<div id="sidebar_subscribe">
<img id="current_cover_subscribe" src="images/current_cover_subscribe.jpg" width="61" height="79" alt="Current Cover" />
<p class="lg">Subscribe to Imbibe</p>
<p class="med">and save 46% off the newsstand price!</p>
<p class="sm">6 issues for just $20</p>
<p class="form">
<br /><br />
Name <br />
Address 1 <br />
Address 2 <br />
City <br />
State, Zip <br />
Email <br />
Submit <br />
</p>

</div>